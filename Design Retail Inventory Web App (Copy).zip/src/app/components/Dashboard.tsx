import {
  AreaChart,
  Area,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
} from "recharts";
import { TrendingUp, TrendingDown, Package, AlertTriangle, CheckCircle, Clock, Zap, ArrowRight } from "lucide-react";

const salesTrend = [
  { month: "Jan", revenue: 42000000, stock: 3200 },
  { month: "Feb", revenue: 51000000, stock: 2900 },
  { month: "Mar", revenue: 47000000, stock: 3100 },
  { month: "Apr", revenue: 63000000, stock: 2700 },
  { month: "May", revenue: 58000000, stock: 3400 },
  { month: "Jun", revenue: 72000000, stock: 3600 },
];

const categoryStock = [
  { category: "Beverages", fastMoving: 420, slowMoving: 180, deadStock: 45 },
  { category: "Snacks", fastMoving: 310, slowMoving: 220, deadStock: 80 },
  { category: "Toiletries", fastMoving: 190, slowMoving: 140, deadStock: 30 },
  { category: "Dairy", fastMoving: 380, slowMoving: 90, deadStock: 15 },
  { category: "Frozen", fastMoving: 150, slowMoving: 200, deadStock: 60 },
];

const pendingApprovals = [
  { id: "PO-2024-089", type: "Purchase Order", supplier: "PT Sumber Makmur", amount: "Rp 12.500.000", urgency: "high" },
  { id: "PO-2024-090", type: "Purchase Order", supplier: "CV Berkah Jaya", amount: "Rp 8.200.000", urgency: "medium" },
  { id: "ADJ-2024-031", type: "Stock Adjustment", supplier: "Admin: Dewi R.", amount: "-45 units (Variance)", urgency: "low" },
];

const kpiCards = [
  { label: "Total Revenue (Jun)", value: "Rp 72.4M", change: "+12.3%", up: true, icon: TrendingUp, color: "text-emerald-600", bg: "bg-emerald-50" },
  { label: "Total SKU Active", value: "2,847", change: "+23 new", up: true, icon: Package, color: "text-blue-600", bg: "bg-blue-50" },
  { label: "Low Stock Alerts", value: "38", change: "Needs reorder", up: false, icon: AlertTriangle, color: "text-amber-600", bg: "bg-amber-50" },
  { label: "Dead Stock Items", value: "124", change: "Rp 4.2M tied up", up: false, icon: TrendingDown, color: "text-red-600", bg: "bg-red-50" },
];

const stockMatrix = [
  { label: "Fast Moving", count: 1450, desc: "Turnover < 7 days", color: "bg-emerald-500", textColor: "text-emerald-700", bg: "bg-emerald-50 border-emerald-200" },
  { label: "Slow Moving", count: 830, desc: "Turnover 7–30 days", color: "bg-amber-500", textColor: "text-amber-700", bg: "bg-amber-50 border-amber-200" },
  { label: "Dead Stock", count: 124, desc: "No movement > 30 days", color: "bg-red-500", textColor: "text-red-700", bg: "bg-red-50 border-red-200" },
];

function formatIDR(val: number) {
  return `Rp ${(val / 1000000).toFixed(0)}M`;
}

export function Dashboard() {
  return (
    <div className="p-6 space-y-6 min-h-screen">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl text-foreground">Manager Dashboard</h1>
          <p className="text-sm text-muted-foreground mt-0.5">Strategic overview — June 2026</p>
        </div>
        <div className="flex items-center gap-2 text-xs bg-white border border-border rounded-lg px-3 py-2 text-muted-foreground shadow-sm">
          <Clock className="w-3.5 h-3.5" />
          Last synced: Today, 09:41 AM
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {kpiCards.map((kpi) => (
          <div key={kpi.label} className="bg-card rounded-xl border border-border p-4 shadow-sm">
            <div className="flex items-start justify-between">
              <div className={`w-9 h-9 rounded-lg ${kpi.bg} flex items-center justify-center`}>
                <kpi.icon className={`w-4.5 h-4.5 ${kpi.color}`} />
              </div>
              <span className={`text-xs px-2 py-0.5 rounded-full ${kpi.up ? "bg-emerald-50 text-emerald-700" : "bg-red-50 text-red-700"}`}>
                {kpi.change}
              </span>
            </div>
            <p className="mt-3 text-muted-foreground" style={{ fontSize: "12px" }}>{kpi.label}</p>
            <p className="mt-0.5 text-foreground" style={{ fontSize: "1.35rem", fontWeight: 700, letterSpacing: "-0.02em" }}>{kpi.value}</p>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Revenue Trend */}
        <div className="lg:col-span-2 bg-card rounded-xl border border-border p-5 shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-foreground">Revenue & Stock Trend</h2>
            <span className="text-xs text-muted-foreground bg-muted px-2 py-1 rounded-md">Last 6 months</span>
          </div>
          <ResponsiveContainer width="100%" height={220}>
            <AreaChart data={salesTrend} margin={{ top: 4, right: 4, left: 0, bottom: 0 }}>
              <defs>
                <linearGradient id="revGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#2563eb" stopOpacity={0.15} />
                  <stop offset="95%" stopColor="#2563eb" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
              <XAxis dataKey="month" tick={{ fontSize: 11, fill: "#94a3b8" }} axisLine={false} tickLine={false} />
              <YAxis tickFormatter={formatIDR} tick={{ fontSize: 11, fill: "#94a3b8" }} axisLine={false} tickLine={false} />
              <Tooltip formatter={(v: number, n: string) => n === "revenue" ? [`Rp ${(v/1000000).toFixed(1)}M`, "Revenue"] : [v, "Stock Units"]} />
              <Area type="monotone" dataKey="revenue" stroke="#2563eb" fill="url(#revGrad)" strokeWidth={2} dot={false} />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* Stock Classification Matrix */}
        <div className="bg-card rounded-xl border border-border p-5 shadow-sm">
          <h2 className="text-foreground mb-4">Stock Classification</h2>
          <div className="space-y-3">
            {stockMatrix.map((m) => (
              <div key={m.label} className={`rounded-lg border p-3.5 ${m.bg}`}>
                <div className="flex items-center justify-between mb-1.5">
                  <span className={`text-sm ${m.textColor}`} style={{ fontWeight: 600 }}>{m.label}</span>
                  <span className={`text-lg ${m.textColor}`} style={{ fontWeight: 700 }}>{m.count.toLocaleString()}</span>
                </div>
                <p className="text-xs text-muted-foreground">{m.desc}</p>
                <div className="mt-2 bg-white/60 rounded-full h-1.5 overflow-hidden">
                  <div className={`h-full rounded-full ${m.color}`} style={{ width: `${(m.count / 2404) * 100}%` }} />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Category Bar Chart */}
        <div className="lg:col-span-2 bg-card rounded-xl border border-border p-5 shadow-sm">
          <h2 className="text-foreground mb-4">Stock by Category</h2>
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={categoryStock} barSize={12} margin={{ top: 4, right: 4, left: 0, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" vertical={false} />
              <XAxis dataKey="category" tick={{ fontSize: 11, fill: "#94a3b8" }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 11, fill: "#94a3b8" }} axisLine={false} tickLine={false} />
              <Tooltip />
              <Legend wrapperStyle={{ fontSize: "11px" }} />
              <Bar dataKey="fastMoving" name="Fast Moving" fill="#2563eb" radius={[3, 3, 0, 0]} />
              <Bar dataKey="slowMoving" name="Slow Moving" fill="#d97706" radius={[3, 3, 0, 0]} />
              <Bar dataKey="deadStock" name="Dead Stock" fill="#dc2626" radius={[3, 3, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* AI Recommendation */}
        <div className="bg-card rounded-xl border border-border p-5 shadow-sm flex flex-col">
          <div className="flex items-center gap-2 mb-3">
            <div className="w-7 h-7 rounded-lg bg-primary flex items-center justify-center">
              <Zap className="w-3.5 h-3.5 text-white" />
            </div>
            <h2 className="text-foreground">AI Recommendations</h2>
          </div>
          <div className="space-y-3 flex-1">
            {[
              { title: "Bundle Promo: Dead Stock", desc: "124 items with 0 movement. Create bundle discount to clear Rp 4.2M stock.", tag: "Action Required", tagColor: "bg-red-100 text-red-700" },
              { title: "Reorder: Mineral Water", desc: "Stock at 42 units (below reorder point of 100). Place PO to PT Sumber.", tag: "Low Stock", tagColor: "bg-amber-100 text-amber-700" },
              { title: "Optimize: Dairy Shelf", desc: "Dairy category shows 38% slow-moving rate. Review pricing strategy.", tag: "Optimize", tagColor: "bg-blue-100 text-blue-700" },
            ].map((r) => (
              <div key={r.title} className="p-3 rounded-lg bg-muted/50 border border-border/50">
                <div className="flex items-start justify-between gap-2 mb-1">
                  <p className="text-sm text-foreground" style={{ fontWeight: 600 }}>{r.title}</p>
                  <span className={`text-[10px] px-1.5 py-0.5 rounded-full shrink-0 ${r.tagColor}`}>{r.tag}</span>
                </div>
                <p className="text-xs text-muted-foreground">{r.desc}</p>
              </div>
            ))}
          </div>
          <button className="mt-4 w-full flex items-center justify-center gap-2 py-2 rounded-lg bg-primary text-white text-sm transition-opacity hover:opacity-90">
            View All Recommendations <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Pending Approvals */}
      <div className="bg-card rounded-xl border border-border shadow-sm overflow-hidden">
        <div className="flex items-center justify-between px-5 py-4 border-b border-border">
          <div className="flex items-center gap-2">
            <h2 className="text-foreground">Pending Approvals</h2>
            <span className="bg-destructive text-white text-xs px-2 py-0.5 rounded-full">{pendingApprovals.length}</span>
          </div>
          <button className="text-xs text-primary hover:underline">View All</button>
        </div>
        <div className="divide-y divide-border">
          {pendingApprovals.map((p) => (
            <div key={p.id} className="flex items-center gap-4 px-5 py-3.5 hover:bg-muted/30 transition-colors">
              <div className={`w-1.5 h-8 rounded-full shrink-0 ${p.urgency === "high" ? "bg-red-500" : p.urgency === "medium" ? "bg-amber-500" : "bg-blue-400"}`} />
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <p className="text-sm text-foreground" style={{ fontWeight: 600 }}>{p.id}</p>
                  <span className="text-xs bg-secondary text-secondary-foreground px-2 py-0.5 rounded-full">{p.type}</span>
                </div>
                <p className="text-xs text-muted-foreground mt-0.5">{p.supplier}</p>
              </div>
              <p className="text-sm text-foreground shrink-0" style={{ fontWeight: 600 }}>{p.amount}</p>
              <div className="flex gap-2 shrink-0">
                <button className="flex items-center gap-1 text-xs px-3 py-1.5 rounded-md bg-emerald-50 text-emerald-700 border border-emerald-200 hover:bg-emerald-100 transition-colors">
                  <CheckCircle className="w-3 h-3" /> Approve
                </button>
                <button className="text-xs px-3 py-1.5 rounded-md bg-muted text-muted-foreground border border-border hover:bg-secondary transition-colors">
                  Review
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
