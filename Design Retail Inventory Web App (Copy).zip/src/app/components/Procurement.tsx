import { useState } from "react";
import { Plus, Eye, CheckCircle, ScanLine, X, Truck } from "lucide-react";

const poList = [
  { id: "PO-2024-089", supplier: "PT Sumber Makmur", date: "2026-06-07", total: 12500000, items: 8, status: "pending" },
  { id: "PO-2024-088", supplier: "CV Berkah Jaya", date: "2026-06-05", total: 8200000, items: 5, status: "approved" },
  { id: "PO-2024-087", supplier: "PT Maju Bersama", date: "2026-06-03", total: 21750000, items: 12, status: "received" },
  { id: "PO-2024-086", supplier: "UD Sari Rasa", date: "2026-06-01", total: 6400000, items: 4, status: "received" },
  { id: "PO-2024-085", supplier: "PT Global Distribusi", date: "2026-05-28", total: 34500000, items: 20, status: "draft" },
];

const poDetailItems = [
  { sku: "BEV-MW-001", name: "Aqua Mineral Water 600ml", qty: 500, unit: "pcs", unitPrice: 3500, total: 1750000 },
  { sku: "BEV-TEH-012", name: "Teh Botol Sosro 450ml", qty: 300, unit: "pcs", unitPrice: 4200, total: 1260000 },
  { sku: "DRY-IND-007", name: "Indomie Goreng Original", qty: 600, unit: "pcs", unitPrice: 2800, total: 1680000 },
  { sku: "SNK-CHI-003", name: "Chitato Potato Chips 68g", qty: 200, unit: "pcs", unitPrice: 9500, total: 1900000 },
  { sku: "DRY-GUL-004", name: "Gulaku Gula Pasir 1kg", qty: 240, unit: "pcs", unitPrice: 13000, total: 3120000 },
];

const statusConfig = {
  draft: { label: "Draft", className: "bg-gray-100 text-gray-600 border-gray-200" },
  pending: { label: "Pending Approval", className: "bg-amber-50 text-amber-700 border-amber-200" },
  approved: { label: "Approved", className: "bg-blue-50 text-blue-700 border-blue-200" },
  received: { label: "Received", className: "bg-emerald-50 text-emerald-700 border-emerald-200" },
};

export function Procurement() {
  const [selectedPO, setSelectedPO] = useState<string | null>(null);
  const [scanModalOpen, setScanModalOpen] = useState(false);

  const detail = poList.find((p) => p.id === selectedPO);

  return (
    <div className="p-6 space-y-5 min-h-screen">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl text-foreground">Procurement & Purchase Orders</h1>
          <p className="text-sm text-muted-foreground mt-0.5">Manage supplier orders and incoming goods</p>
        </div>
        <button className="flex items-center gap-2 text-sm px-4 py-2 rounded-lg bg-primary text-white hover:opacity-90 transition-opacity">
          <Plus className="w-4 h-4" /> Create PO
        </button>
      </div>

      <div className="grid grid-cols-3 gap-4">
        {[
          { label: "Draft POs", value: "1", color: "text-gray-700", bg: "bg-gray-50" },
          { label: "Pending Approval", value: "1", color: "text-amber-700", bg: "bg-amber-50" },
          { label: "This Month Total", value: "Rp 83.4M", color: "text-blue-700", bg: "bg-blue-50" },
        ].map((s) => (
          <div key={s.label} className={`rounded-xl border border-border p-4 ${s.bg} shadow-sm`}>
            <p className="text-xs text-muted-foreground">{s.label}</p>
            <p className={`mt-1 ${s.color}`} style={{ fontSize: "1.5rem", fontWeight: 700 }}>{s.value}</p>
          </div>
        ))}
      </div>

      <div className={`grid gap-5 ${selectedPO ? "lg:grid-cols-2" : "grid-cols-1"}`}>
        {/* PO List */}
        <div className="bg-card rounded-xl border border-border shadow-sm overflow-hidden">
          <div className="px-5 py-4 border-b border-border">
            <h2 className="text-foreground">Purchase Order List</h2>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="bg-muted/40 border-b border-border">
                  {["PO ID", "Supplier", "Date", "Total (Rp)", "Items", "Status", "Actions"].map((h) => (
                    <th key={h} className="text-left py-3 px-4 text-xs text-muted-foreground" style={{ fontWeight: 600, whiteSpace: "nowrap" }}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {poList.map((po) => {
                  const sc = statusConfig[po.status as keyof typeof statusConfig];
                  return (
                    <tr key={po.id} className={`border-b border-border hover:bg-muted/20 transition-colors cursor-pointer ${selectedPO === po.id ? "bg-blue-50/50" : ""}`}>
                      <td className="py-3 px-4 font-mono text-xs text-foreground" style={{ fontWeight: 600 }}>{po.id}</td>
                      <td className="py-3 px-4 text-foreground">{po.supplier}</td>
                      <td className="py-3 px-4 text-muted-foreground text-xs">{po.date}</td>
                      <td className="py-3 px-4 text-foreground" style={{ fontWeight: 600 }}>{po.total.toLocaleString("id-ID")}</td>
                      <td className="py-3 px-4 text-center text-muted-foreground">{po.items}</td>
                      <td className="py-3 px-4">
                        <span className={`text-xs px-2 py-1 rounded-full border ${sc.className}`}>{sc.label}</span>
                      </td>
                      <td className="py-3 px-4">
                        <div className="flex items-center gap-1">
                          <button onClick={() => setSelectedPO(selectedPO === po.id ? null : po.id)} className="text-xs px-2.5 py-1 rounded-md bg-blue-50 text-blue-700 hover:bg-blue-100 transition-colors flex items-center gap-1">
                            <Eye className="w-3 h-3" /> View
                          </button>
                          {po.status === "pending" && (
                            <button className="text-xs px-2.5 py-1 rounded-md bg-emerald-50 text-emerald-700 hover:bg-emerald-100 transition-colors flex items-center gap-1">
                              <CheckCircle className="w-3 h-3" /> Approve
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/* PO Detail View */}
        {detail && (
          <div className="bg-card rounded-xl border border-border shadow-sm overflow-hidden flex flex-col">
            <div className="flex items-center justify-between px-5 py-4 border-b border-border">
              <div>
                <h2 className="text-foreground">{detail.id}</h2>
                <p className="text-xs text-muted-foreground mt-0.5">{detail.supplier} — {detail.date}</p>
              </div>
              <button onClick={() => setSelectedPO(null)} className="text-muted-foreground hover:text-foreground">
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="flex-1 overflow-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="bg-muted/40 border-b border-border">
                    {["SKU", "Product", "Qty", "Unit Price", "Total"].map((h) => (
                      <th key={h} className="text-left py-2.5 px-4 text-xs text-muted-foreground" style={{ fontWeight: 600 }}>{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {poDetailItems.map((item) => (
                    <tr key={item.sku} className="border-b border-border hover:bg-muted/10">
                      <td className="py-2.5 px-4 font-mono text-xs text-muted-foreground">{item.sku}</td>
                      <td className="py-2.5 px-4 text-foreground">{item.name}</td>
                      <td className="py-2.5 px-4 text-center text-foreground">{item.qty}</td>
                      <td className="py-2.5 px-4 text-muted-foreground">{item.unitPrice.toLocaleString("id-ID")}</td>
                      <td className="py-2.5 px-4 text-foreground" style={{ fontWeight: 600 }}>{item.total.toLocaleString("id-ID")}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <div className="px-5 py-4 border-t border-border bg-muted/10">
              <div className="flex items-center justify-between mb-4">
                <p className="text-sm text-muted-foreground">Grand Total</p>
                <p className="text-foreground" style={{ fontWeight: 700, fontSize: "1.1rem" }}>
                  Rp {poDetailItems.reduce((s, i) => s + i.total, 0).toLocaleString("id-ID")}
                </p>
              </div>
              <div className="flex gap-2">
                {detail.status === "pending" && (
                  <button className="flex-1 flex items-center justify-center gap-2 py-2 text-sm rounded-lg bg-emerald-500 text-white hover:opacity-90 transition-opacity">
                    <CheckCircle className="w-4 h-4" /> Approve PO
                  </button>
                )}
                {detail.status === "approved" && (
                  <button onClick={() => setScanModalOpen(true)} className="flex-1 flex items-center justify-center gap-2 py-2 text-sm rounded-lg bg-primary text-white hover:opacity-90 transition-opacity">
                    <ScanLine className="w-4 h-4" /> Scan to Validate Goods
                  </button>
                )}
                <button className="flex-1 flex items-center justify-center gap-2 py-2 text-sm rounded-lg bg-muted text-muted-foreground border border-border hover:bg-secondary transition-colors">
                  <Truck className="w-4 h-4" /> Mark Received
                </button>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Scan Validation Modal */}
      {scanModalOpen && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center">
          <div className="bg-card rounded-2xl shadow-2xl p-6 w-full max-w-sm mx-4">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-foreground">Validate Incoming Goods</h2>
              <button onClick={() => setScanModalOpen(false)} className="text-muted-foreground hover:text-foreground">
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="bg-gray-900 rounded-xl aspect-video flex items-center justify-center mb-4 relative">
              <ScanLine className="w-10 h-10 text-primary animate-pulse" />
              <div className="absolute top-1/2 left-4 right-4 h-px bg-primary/60" />
              <p className="text-xs text-white/40 absolute bottom-3">Point camera at barcode</p>
            </div>
            <p className="text-xs text-muted-foreground mb-2">Scanned Items: <span className="text-foreground font-semibold">3 / 5</span></p>
            <div className="space-y-1.5 mb-4">
              {poDetailItems.slice(0, 3).map((item) => (
                <div key={item.sku} className="flex items-center gap-2 text-xs">
                  <CheckCircle className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
                  <span className="text-foreground">{item.name}</span>
                  <span className="ml-auto text-muted-foreground">{item.qty} pcs</span>
                </div>
              ))}
            </div>
            <button onClick={() => setScanModalOpen(false)} className="w-full py-2 text-sm bg-primary text-white rounded-lg hover:opacity-90 transition-opacity">
              Confirm & Receive Goods
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
