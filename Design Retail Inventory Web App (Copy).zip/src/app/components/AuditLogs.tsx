import { useState } from "react";
import { Search, Filter, Download, ChevronDown } from "lucide-react";

const logs = [
  { id: "LOG-00421", timestamp: "2026-06-09 09:41:22", user: "Budi Santoso", role: "Manager", action: "APPROVE_PO", target: "PO-2024-088", detail: "Approved PO from CV Berkah Jaya (Rp 8.2M)", category: "procurement" },
  { id: "LOG-00420", timestamp: "2026-06-09 08:55:10", user: "Dewi Rahayu", role: "Admin", action: "STOCK_ADJUST", target: "PRD-001", detail: "Adjusted Aqua 600ml: +50 units (stock count correction)", category: "inventory" },
  { id: "LOG-00419", timestamp: "2026-06-09 08:30:44", user: "Ahmad Fauzi", role: "Cashier", action: "SALE_TXN", target: "TXN-240603", detail: "Sale completed: Rp 47,500 — 3 items", category: "pos" },
  { id: "LOG-00418", timestamp: "2026-06-09 08:12:03", user: "Rina Wahyuni", role: "Cashier", action: "RETURN_PROC", target: "RTN-2024-018", detail: "Processed return: 2x Oreo Double Stuff — moved to Quarantine", category: "return" },
  { id: "LOG-00417", timestamp: "2026-06-08 17:45:51", user: "Budi Santoso", role: "Manager", action: "CREATE_PO", target: "PO-2024-089", detail: "Created PO for PT Sumber Makmur (8 items, Rp 12.5M)", category: "procurement" },
  { id: "LOG-00416", timestamp: "2026-06-08 16:20:18", user: "Dewi Rahayu", role: "Admin", action: "CYCLE_COUNT", target: "OPNAME-2024-042", detail: "Submitted cycle count — 4 variances reported", category: "inventory" },
  { id: "LOG-00415", timestamp: "2026-06-08 14:58:33", user: "System", role: "Auto", action: "REORDER_ALERT", target: "PRD-006", detail: "Auto-alert: Beras Ramos 5kg below reorder point (15 < 30)", category: "system" },
  { id: "LOG-00414", timestamp: "2026-06-08 13:22:07", user: "Rina Wahyuni", role: "Cashier", action: "SALE_TXN", target: "TXN-240602", detail: "Sale completed: Rp 98,000 — 4 items", category: "pos" },
  { id: "LOG-00413", timestamp: "2026-06-08 11:05:42", user: "Dewi Rahayu", role: "Admin", action: "ADD_PRODUCT", target: "PRD-011", detail: "Added new SKU: Nutrisari Jeruk 500ml (BEV-JUS-008)", category: "inventory" },
  { id: "LOG-00412", timestamp: "2026-06-07 15:30:19", user: "Budi Santoso", role: "Manager", action: "LOGIN", target: "USER-001", detail: "Manager logged in from 192.168.1.15", category: "auth" },
];

const categoryConfig = {
  procurement: { label: "Procurement", className: "bg-blue-50 text-blue-700 border-blue-200" },
  inventory: { label: "Inventory", className: "bg-violet-50 text-violet-700 border-violet-200" },
  pos: { label: "POS", className: "bg-emerald-50 text-emerald-700 border-emerald-200" },
  return: { label: "Return", className: "bg-amber-50 text-amber-700 border-amber-200" },
  system: { label: "System", className: "bg-gray-50 text-gray-600 border-gray-200" },
  auth: { label: "Auth", className: "bg-slate-50 text-slate-600 border-slate-200" },
};

const actionColors: Record<string, string> = {
  APPROVE_PO: "text-emerald-600",
  STOCK_ADJUST: "text-violet-600",
  SALE_TXN: "text-blue-600",
  RETURN_PROC: "text-amber-600",
  CREATE_PO: "text-blue-600",
  CYCLE_COUNT: "text-violet-600",
  REORDER_ALERT: "text-red-600",
  ADD_PRODUCT: "text-emerald-600",
  LOGIN: "text-gray-500",
};

export function AuditLogs() {
  const [search, setSearch] = useState("");
  const [activeCategory, setActiveCategory] = useState("all");

  const categories = ["all", "procurement", "inventory", "pos", "return", "system", "auth"];

  const filtered = logs.filter((log) => {
    const matchSearch = log.action.toLowerCase().includes(search.toLowerCase()) ||
      log.user.toLowerCase().includes(search.toLowerCase()) ||
      log.detail.toLowerCase().includes(search.toLowerCase()) ||
      log.target.toLowerCase().includes(search.toLowerCase());
    const matchCat = activeCategory === "all" || log.category === activeCategory;
    return matchSearch && matchCat;
  });

  return (
    <div className="p-6 space-y-5 min-h-screen">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl text-foreground">Audit Logs</h1>
          <p className="text-sm text-muted-foreground mt-0.5">Complete activity trail — {logs.length} entries today</p>
        </div>
        <button className="flex items-center gap-2 text-sm px-4 py-2 rounded-lg bg-white border border-border text-foreground hover:bg-muted transition-colors shadow-sm">
          <Download className="w-4 h-4" /> Export CSV
        </button>
      </div>

      {/* Filters */}
      <div className="bg-card rounded-xl border border-border p-4 shadow-sm space-y-3">
        <div className="flex flex-col sm:flex-row gap-3">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search by user, action, or target..."
              className="w-full pl-9 pr-4 py-2 text-sm rounded-lg border border-border bg-input-background focus:outline-none focus:ring-2 focus:ring-ring"
            />
          </div>
          <button className="flex items-center gap-2 px-4 py-2 text-sm bg-secondary text-secondary-foreground border border-border rounded-lg hover:bg-muted transition-colors shrink-0">
            <Filter className="w-4 h-4" /> Date Range <ChevronDown className="w-3.5 h-3.5" />
          </button>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`text-xs px-3 py-1.5 rounded-full border capitalize transition-all ${
                activeCategory === cat
                  ? "bg-primary text-white border-primary"
                  : "bg-white text-muted-foreground border-border hover:bg-muted"
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Log Table */}
      <div className="bg-card rounded-xl border border-border shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-muted/40 border-b border-border">
                {["Log ID", "Timestamp", "User", "Role", "Action", "Target", "Details", "Category"].map((h) => (
                  <th key={h} className="text-left py-3 px-4 text-xs text-muted-foreground" style={{ fontWeight: 600, whiteSpace: "nowrap" }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.map((log, i) => {
                const cc = categoryConfig[log.category as keyof typeof categoryConfig];
                return (
                  <tr key={log.id} className={`border-b border-border hover:bg-muted/20 transition-colors ${i % 2 === 0 ? "" : "bg-muted/5"}`}>
                    <td className="py-3 px-4 font-mono text-xs text-muted-foreground">{log.id}</td>
                    <td className="py-3 px-4 font-mono text-xs text-muted-foreground whitespace-nowrap">{log.timestamp}</td>
                    <td className="py-3 px-4 text-foreground whitespace-nowrap" style={{ fontWeight: 500 }}>{log.user}</td>
                    <td className="py-3 px-4 text-muted-foreground text-xs">{log.role}</td>
                    <td className="py-3 px-4">
                      <span className={`font-mono text-xs ${actionColors[log.action] || "text-foreground"}`} style={{ fontWeight: 600 }}>{log.action}</span>
                    </td>
                    <td className="py-3 px-4 font-mono text-xs text-foreground">{log.target}</td>
                    <td className="py-3 px-4 text-xs text-muted-foreground max-w-xs truncate">{log.detail}</td>
                    <td className="py-3 px-4">
                      <span className={`text-[10px] px-2 py-0.5 rounded-full border ${cc.className}`}>{cc.label}</span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
        <div className="px-5 py-3 border-t border-border flex items-center justify-between text-xs text-muted-foreground">
          <span>Showing {filtered.length} of {logs.length} entries</span>
          <div className="flex items-center gap-1">
            {[1, 2, 3, "..."].map((p) => (
              <button key={String(p)} className={`w-7 h-7 rounded-md text-xs ${p === 1 ? "bg-primary text-white" : "bg-muted text-muted-foreground hover:bg-secondary"}`}>{p}</button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
