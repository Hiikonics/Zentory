import {
  LayoutDashboard,
  Package,
  ShoppingCart,
  CreditCard,
  RotateCcw,
  ClipboardList,
  ChevronRight,
  Warehouse,
  Bell,
  User,
} from "lucide-react";

const navItems = [
  { id: "dashboard", label: "Dashboard", icon: LayoutDashboard },
  { id: "inventory", label: "Inventory", icon: Package },
  { id: "procurement", label: "Procurement (PO)", icon: ShoppingCart },
  { id: "pos", label: "POS Module", icon: CreditCard },
  { id: "returns", label: "Sales Returns", icon: RotateCcw },
  { id: "audit", label: "Audit Logs", icon: ClipboardList },
];

interface SidebarProps {
  activePage: string;
  onNavigate: (page: string) => void;
}

export function Sidebar({ activePage, onNavigate }: SidebarProps) {
  return (
    <aside className="flex flex-col w-60 min-h-screen bg-sidebar text-sidebar-foreground shrink-0">
      <div className="flex items-center gap-2.5 px-5 py-5 border-b border-sidebar-border">
        <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center shrink-0">
          <Warehouse className="w-4.5 h-4.5 text-white" />
        </div>
        <div>
          <p className="text-white leading-none" style={{ fontWeight: 700, fontSize: "1.05rem", letterSpacing: "-0.01em" }}>
            Zentory
          </p>
          <p className="text-xs text-sidebar-foreground/50 mt-0.5">Smart Inventory</p>
        </div>
      </div>

      <nav className="flex-1 px-3 py-4 space-y-0.5 overflow-y-auto">
        <p className="px-2 text-[10px] tracking-widest text-sidebar-foreground/40 mb-2">MAIN MENU</p>
        {navItems.map(({ id, label, icon: Icon }) => {
          const active = activePage === id;
          return (
            <button
              key={id}
              onClick={() => onNavigate(id)}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-md text-sm transition-all duration-150 group ${
                active
                  ? "bg-primary text-white"
                  : "text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
              }`}
            >
              <Icon className={`w-4 h-4 shrink-0 ${active ? "text-white" : "text-sidebar-foreground/60 group-hover:text-sidebar-accent-foreground"}`} />
              <span className="flex-1 text-left">{label}</span>
              {active && <ChevronRight className="w-3.5 h-3.5 opacity-60" />}
            </button>
          );
        })}
      </nav>

      <div className="px-3 py-4 border-t border-sidebar-border space-y-1">
        <button className="w-full flex items-center gap-3 px-3 py-2.5 rounded-md text-sm text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground transition-all">
          <Bell className="w-4 h-4 shrink-0 text-sidebar-foreground/60" />
          <span className="flex-1 text-left">Notifications</span>
          <span className="bg-destructive text-white text-[10px] font-semibold rounded-full px-1.5 py-0.5">3</span>
        </button>
        <div className="flex items-center gap-3 px-3 py-2.5 rounded-md hover:bg-sidebar-accent cursor-pointer transition-all">
          <div className="w-7 h-7 rounded-full bg-primary/30 flex items-center justify-center shrink-0">
            <User className="w-3.5 h-3.5 text-primary-foreground" />
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-xs text-white truncate">Budi Santoso</p>
            <p className="text-[11px] text-sidebar-foreground/50">Manager</p>
          </div>
        </div>
      </div>
    </aside>
  );
}
