import { useState } from "react";
import { Search, ShoppingCart, Trash2, CreditCard, Banknote, X, AlertTriangle } from "lucide-react";
import { toast } from "sonner";

const products = [
  { id: "BEV-MW-001", name: "Aqua 600ml", price: 4500, stock: 0, emoji: "💧" },
  { id: "BEV-TEH-012", name: "Teh Botol 450ml", price: 5000, stock: 318, emoji: "🍵" },
  { id: "SNK-CHI-003", name: "Chitato 68g", price: 12500, stock: 85, emoji: "🥨" },
  { id: "DRY-IND-007", name: "Indomie Goreng", price: 3500, stock: 520, emoji: "🍜" },
  { id: "TOIL-SOF-022", name: "Softex Body Wash", price: 28500, stock: 78, emoji: "🧴" },
  { id: "DRY-GUL-004", name: "Gulaku 1kg", price: 16500, stock: 205, emoji: "🍚" },
  { id: "FRZ-CPK-011", name: "So Good Nugget", price: 35000, stock: 6, emoji: "🍗" },
  { id: "BEV-KOP-031", name: "Kopi Kapal Api", price: 22000, stock: 97, emoji: "☕" },
  { id: "SNK-ORE-015", name: "Oreo Double Stuff", price: 18000, stock: 0, emoji: "🍪" },
  { id: "DRY-ROS-009", name: "Beras 5kg", price: 72000, stock: 15, emoji: "🌾" },
  { id: "BEV-JUS-008", name: "Nutrisari Jeruk", price: 3200, stock: 420, emoji: "🍊" },
  { id: "SNK-PRN-021", name: "Pringles Original", price: 32000, stock: 44, emoji: "🍟" },
];

interface CartItem {
  id: string;
  name: string;
  price: number;
  qty: number;
  stock: number;
}

export function POS() {
  const [cart, setCart] = useState<CartItem[]>([]);
  const [search, setSearch] = useState("");
  const [checkoutOpen, setCheckoutOpen] = useState(false);
  const [paid, setPaid] = useState("");

  const filtered = products.filter((p) => p.name.toLowerCase().includes(search.toLowerCase()));

  const addToCart = (product: typeof products[0]) => {
    if (product.stock === 0) {
      toast.error("Stok Tidak Tersedia!", {
        description: `${product.name} is currently out of stock.`,
        icon: <AlertTriangle className="w-4 h-4" />,
      });
      return;
    }
    setCart((prev) => {
      const existing = prev.find((c) => c.id === product.id);
      if (existing) {
        if (existing.qty >= product.stock) {
          toast.warning("Stok Tidak Cukup", { description: `Only ${product.stock} units available.` });
          return prev;
        }
        return prev.map((c) => c.id === product.id ? { ...c, qty: c.qty + 1 } : c);
      }
      return [...prev, { id: product.id, name: product.name, price: product.price, qty: 1, stock: product.stock }];
    });
  };

  const removeFromCart = (id: string) => setCart((prev) => prev.filter((c) => c.id !== id));
  const updateQty = (id: string, qty: number) => {
    if (qty <= 0) return removeFromCart(id);
    setCart((prev) => prev.map((c) => c.id === id ? { ...c, qty } : c));
  };

  const subtotal = cart.reduce((s, c) => s + c.price * c.qty, 0);
  const tax = Math.round(subtotal * 0.11);
  const total = subtotal + tax;
  const change = Math.max(0, parseInt(paid.replace(/\D/g, "") || "0") - total);

  const handleCheckout = () => {
    toast.success("Transaction Complete!", { description: `TXN-${Date.now().toString().slice(-6)} — Rp ${total.toLocaleString("id-ID")}` });
    setCart([]);
    setCheckoutOpen(false);
    setPaid("");
  };

  return (
    <div className="flex h-screen overflow-hidden">
      {/* Product Grid */}
      <div className="flex-1 flex flex-col overflow-hidden p-5 space-y-4">
        <div>
          <h1 className="text-xl text-foreground">Point of Sales</h1>
          <p className="text-sm text-muted-foreground">Select products to add to cart</p>
        </div>
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search products..."
            className="w-full pl-9 pr-4 py-2.5 text-sm rounded-xl border border-border bg-card focus:outline-none focus:ring-2 focus:ring-ring shadow-sm"
          />
        </div>
        <div className="flex-1 overflow-y-auto">
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3 pb-4">
            {filtered.map((p) => (
              <button
                key={p.id}
                onClick={() => addToCart(p)}
                className={`relative flex flex-col items-center justify-center gap-2 p-4 rounded-xl border-2 transition-all min-h-[110px] text-center ${
                  p.stock === 0
                    ? "border-red-200 bg-red-50/50 cursor-not-allowed opacity-70"
                    : "border-border bg-card hover:border-primary hover:bg-blue-50/30 hover:shadow-md active:scale-95"
                }`}
              >
                {p.stock === 0 && (
                  <span className="absolute top-2 right-2 text-[9px] bg-red-500 text-white px-1.5 py-0.5 rounded-full">OUT</span>
                )}
                {p.stock > 0 && p.stock < 20 && (
                  <span className="absolute top-2 right-2 text-[9px] bg-amber-500 text-white px-1.5 py-0.5 rounded-full">LOW</span>
                )}
                <span className="text-3xl">{p.emoji}</span>
                <div>
                  <p className="text-xs text-foreground leading-tight" style={{ fontWeight: 600 }}>{p.name}</p>
                  <p className="text-xs text-primary mt-0.5" style={{ fontWeight: 700 }}>Rp {p.price.toLocaleString("id-ID")}</p>
                </div>
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Cart Panel */}
      <div className="w-80 border-l border-border bg-card flex flex-col shadow-lg">
        <div className="flex items-center gap-2 px-5 py-4 border-b border-border">
          <ShoppingCart className="w-4.5 h-4.5 text-primary" />
          <h2 className="text-foreground flex-1">Cart</h2>
          <span className="bg-primary text-white text-xs px-2 py-0.5 rounded-full">{cart.reduce((s, c) => s + c.qty, 0)}</span>
        </div>

        <div className="flex-1 overflow-y-auto p-4 space-y-2">
          {cart.length === 0 && (
            <div className="flex flex-col items-center justify-center h-full text-center">
              <ShoppingCart className="w-8 h-8 text-muted-foreground/30 mb-2" />
              <p className="text-sm text-muted-foreground">Cart is empty</p>
            </div>
          )}
          {cart.map((item) => (
            <div key={item.id} className="flex items-start gap-3 p-3 rounded-lg bg-muted/30 border border-border/50">
              <div className="flex-1 min-w-0">
                <p className="text-xs text-foreground leading-tight" style={{ fontWeight: 600 }}>{item.name}</p>
                <p className="text-xs text-muted-foreground mt-0.5">Rp {item.price.toLocaleString("id-ID")}</p>
              </div>
              <div className="flex items-center gap-1 shrink-0">
                <button onClick={() => updateQty(item.id, item.qty - 1)} className="w-6 h-6 rounded-md bg-secondary text-foreground text-xs flex items-center justify-center hover:bg-muted transition-colors">−</button>
                <span className="w-6 text-center text-xs text-foreground" style={{ fontWeight: 600 }}>{item.qty}</span>
                <button onClick={() => updateQty(item.id, item.qty + 1)} className="w-6 h-6 rounded-md bg-secondary text-foreground text-xs flex items-center justify-center hover:bg-muted transition-colors">+</button>
              </div>
              <button onClick={() => removeFromCart(item.id)} className="text-red-400 hover:text-red-600 transition-colors">
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </div>
          ))}
        </div>

        <div className="p-4 border-t border-border space-y-2">
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">Subtotal</span>
            <span className="text-foreground">Rp {subtotal.toLocaleString("id-ID")}</span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">PPN (11%)</span>
            <span className="text-foreground">Rp {tax.toLocaleString("id-ID")}</span>
          </div>
          <div className="flex justify-between py-2 border-t border-border">
            <span className="text-foreground" style={{ fontWeight: 700 }}>Total</span>
            <span className="text-primary" style={{ fontWeight: 700, fontSize: "1.05rem" }}>Rp {total.toLocaleString("id-ID")}</span>
          </div>
          <button
            onClick={() => cart.length > 0 && setCheckoutOpen(true)}
            disabled={cart.length === 0}
            className="w-full py-3 rounded-xl bg-primary text-white text-sm flex items-center justify-center gap-2 hover:opacity-90 transition-opacity disabled:opacity-40 disabled:cursor-not-allowed"
            style={{ minHeight: "44px" }}
          >
            <CreditCard className="w-4 h-4" /> Proceed to Checkout
          </button>
        </div>
      </div>

      {/* Checkout Modal */}
      {checkoutOpen && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center">
          <div className="bg-card rounded-2xl shadow-2xl p-6 w-full max-w-sm mx-4">
            <div className="flex items-center justify-between mb-5">
              <h2 className="text-foreground">Payment</h2>
              <button onClick={() => setCheckoutOpen(false)} className="text-muted-foreground hover:text-foreground">
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="bg-muted/30 rounded-xl p-4 mb-4">
              <p className="text-xs text-muted-foreground">Total Amount</p>
              <p className="text-foreground" style={{ fontWeight: 700, fontSize: "1.8rem" }}>Rp {total.toLocaleString("id-ID")}</p>
            </div>
            <div className="space-y-3 mb-4">
              <div>
                <label className="text-xs text-muted-foreground mb-1 block">Cash Received (Rp)</label>
                <input
                  value={paid}
                  onChange={(e) => setPaid(e.target.value)}
                  placeholder="Enter amount..."
                  className="w-full px-3 py-2.5 text-sm rounded-lg border border-border bg-input-background focus:outline-none focus:ring-2 focus:ring-ring"
                  type="number"
                />
              </div>
              {parseInt(paid || "0") >= total && (
                <div className="flex justify-between text-sm py-2 px-3 rounded-lg bg-emerald-50 border border-emerald-200">
                  <span className="text-emerald-700">Change</span>
                  <span className="text-emerald-700" style={{ fontWeight: 700 }}>Rp {change.toLocaleString("id-ID")}</span>
                </div>
              )}
            </div>
            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={handleCheckout}
                className="flex items-center justify-center gap-2 py-3 rounded-xl bg-emerald-500 text-white text-sm hover:opacity-90 transition-opacity"
                style={{ minHeight: "44px" }}
              >
                <Banknote className="w-4 h-4" /> Cash
              </button>
              <button
                onClick={handleCheckout}
                className="flex items-center justify-center gap-2 py-3 rounded-xl bg-primary text-white text-sm hover:opacity-90 transition-opacity"
                style={{ minHeight: "44px" }}
              >
                <CreditCard className="w-4 h-4" /> Card/QRIS
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
