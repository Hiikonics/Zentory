import { useState } from "react";
import { Search, Barcode, Plus, Filter, ScanLine, X, ChevronDown } from "lucide-react";

const products = [
  { id: "PRD-001", sku: "BEV-MW-001", name: "Aqua Mineral Water 600ml", category: "Beverages", price: 4500, stock: 42, reorderPoint: 100, status: "low" },
  { id: "PRD-002", sku: "BEV-TEH-012", name: "Teh Botol Sosro 450ml", category: "Beverages", price: 5000, stock: 318, reorderPoint: 80, status: "ok" },
  { id: "PRD-003", sku: "SNK-CHI-003", name: "Chitato Potato Chips 68g", category: "Snacks", price: 12500, stock: 0, reorderPoint: 50, status: "out" },
  { id: "PRD-004", sku: "DRY-IND-007", name: "Indomie Goreng Original", category: "Dry Goods", price: 3500, stock: 520, reorderPoint: 200, status: "ok" },
  { id: "PRD-005", sku: "TOIL-SOF-022", name: "Softex Body Wash 450ml", category: "Toiletries", price: 28500, stock: 78, reorderPoint: 40, status: "ok" },
  { id: "PRD-006", sku: "DRY-ROS-009", name: "Beras Ramos Mutiara 5kg", category: "Dry Goods", price: 72000, stock: 15, reorderPoint: 30, status: "low" },
  { id: "PRD-007", sku: "FRZ-CPK-011", name: "So Good Chicken Nugget 400g", category: "Frozen", price: 35000, stock: 6, reorderPoint: 20, status: "low" },
  { id: "PRD-008", sku: "DRY-GUL-004", name: "Gulaku Gula Pasir 1kg", category: "Dry Goods", price: 16500, stock: 205, reorderPoint: 100, status: "ok" },
  { id: "PRD-009", sku: "SNK-ORE-015", name: "Oreo Double Stuff 132g", category: "Snacks", price: 18000, stock: 0, reorderPoint: 30, status: "out" },
  { id: "PRD-010", sku: "BEV-KOP-031", name: "Kopi Kapal Api 165g", category: "Beverages", price: 22000, stock: 97, reorderPoint: 60, status: "ok" },
];

const opnameData = [
  { sku: "BEV-MW-001", name: "Aqua Mineral Water 600ml", systemStock: 42, physicalStock: 38, variance: -4 },
  { sku: "SNK-CHI-003", name: "Chitato Potato Chips 68g", systemStock: 0, physicalStock: 3, variance: 3 },
  { sku: "DRY-IND-007", name: "Indomie Goreng Original", systemStock: 520, physicalStock: 518, variance: -2 },
  { sku: "DRY-ROS-009", name: "Beras Ramos Mutiara 5kg", systemStock: 15, physicalStock: 15, variance: 0 },
];

const statusConfig = {
  ok: { label: "In Stock", className: "bg-emerald-50 text-emerald-700 border-emerald-200" },
  low: { label: "Low Stock", className: "bg-amber-50 text-amber-700 border-amber-200" },
  out: { label: "Out of Stock", className: "bg-red-50 text-red-700 border-red-200" },
};

export function Inventory() {
  const [search, setSearch] = useState("");
  const [opnameMode, setOpnameMode] = useState(false);
  const [scannerOpen, setScannerOpen] = useState(false);
  const [reasons, setReasons] = useState<Record<string, string>>({});

  const filtered = products.filter(
    (p) =>
      p.name.toLowerCase().includes(search.toLowerCase()) ||
      p.sku.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="p-6 space-y-5 min-h-screen">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-xl text-foreground">Inventory & Stock Control</h1>
          <p className="text-sm text-muted-foreground mt-0.5">{products.length} active SKUs</p>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => setOpnameMode(!opnameMode)}
            className={`flex items-center gap-2 text-sm px-4 py-2 rounded-lg border transition-all ${
              opnameMode ? "bg-amber-500 text-white border-amber-500" : "bg-white text-foreground border-border hover:bg-muted"
            }`}
          >
            {opnameMode ? "Exit Cycle Counting" : "Start Cycle Counting"}
          </button>
          <button className="flex items-center gap-2 text-sm px-4 py-2 rounded-lg bg-primary text-white hover:opacity-90 transition-opacity">
            <Plus className="w-4 h-4" /> Add Product
          </button>
        </div>
      </div>

      {/* Search & Filter Bar */}
      <div className="bg-card rounded-xl border border-border p-4 shadow-sm flex flex-col sm:flex-row gap-3">
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search by name or SKU..."
            className="w-full pl-9 pr-4 py-2 text-sm rounded-lg border border-border bg-input-background focus:outline-none focus:ring-2 focus:ring-ring"
          />
        </div>
        <button
          onClick={() => setScannerOpen(true)}
          className="flex items-center gap-2 px-4 py-2 text-sm bg-secondary text-secondary-foreground border border-border rounded-lg hover:bg-muted transition-colors shrink-0"
        >
          <Barcode className="w-4 h-4" /> Scan Barcode
        </button>
        <button className="flex items-center gap-2 px-4 py-2 text-sm bg-secondary text-secondary-foreground border border-border rounded-lg hover:bg-muted transition-colors shrink-0">
          <Filter className="w-4 h-4" /> Filter <ChevronDown className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* Barcode Scanner Modal */}
      {scannerOpen && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center">
          <div className="bg-card rounded-2xl shadow-2xl p-6 w-full max-w-sm mx-4">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-foreground">Barcode Scanner</h2>
              <button onClick={() => setScannerOpen(false)} className="text-muted-foreground hover:text-foreground">
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="bg-gray-900 rounded-xl aspect-video flex items-center justify-center mb-4 relative overflow-hidden">
              <div className="absolute inset-0 flex items-center justify-center">
                <ScanLine className="w-12 h-12 text-primary opacity-80 animate-pulse" />
              </div>
              <div className="absolute top-1/2 left-4 right-4 h-px bg-primary/60" />
              <p className="text-xs text-white/50 absolute bottom-3">Camera overlay active</p>
            </div>
            <p className="text-xs text-muted-foreground text-center mb-3">Or enter SKU manually</p>
            <input
              placeholder="Enter SKU (e.g. BEV-MW-001)"
              className="w-full px-3 py-2 text-sm rounded-lg border border-border bg-input-background focus:outline-none focus:ring-2 focus:ring-ring"
            />
            <button
              onClick={() => setScannerOpen(false)}
              className="mt-3 w-full py-2 text-sm bg-primary text-white rounded-lg hover:opacity-90 transition-opacity"
            >
              Lookup Item
            </button>
          </div>
        </div>
      )}

      {/* Cycle Counting Mode */}
      {opnameMode && (
        <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 shadow-sm">
          <div className="flex items-center gap-2 mb-3">
            <div className="w-2.5 h-2.5 rounded-full bg-amber-500 animate-pulse" />
            <p className="text-sm text-amber-800" style={{ fontWeight: 600 }}>Cycle Counting Mode Active — Transactions Frozen</p>
          </div>
          <p className="text-xs text-amber-700 mb-4">Compare system stock vs. physical count. Enter variance reasons before submitting.</p>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-amber-200">
                  {["SKU", "Product Name", "System Stock", "Physical Stock", "Variance", "Reason"].map((h) => (
                    <th key={h} className="text-left py-2 px-3 text-xs text-amber-700" style={{ fontWeight: 600 }}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {opnameData.map((row) => (
                  <tr key={row.sku} className="border-b border-amber-100">
                    <td className="py-2.5 px-3 font-mono text-xs text-amber-900">{row.sku}</td>
                    <td className="py-2.5 px-3 text-amber-900">{row.name}</td>
                    <td className="py-2.5 px-3 text-center text-amber-900">{row.systemStock}</td>
                    <td className="py-2.5 px-3 text-center">
                      <input
                        defaultValue={row.physicalStock}
                        className="w-16 text-center border border-amber-300 rounded px-1 py-0.5 text-sm bg-white"
                        type="number"
                      />
                    </td>
                    <td className={`py-2.5 px-3 text-center font-semibold ${row.variance < 0 ? "text-red-600" : row.variance > 0 ? "text-emerald-600" : "text-muted-foreground"}`}>
                      {row.variance > 0 ? `+${row.variance}` : row.variance}
                    </td>
                    <td className="py-2.5 px-3">
                      <input
                        value={reasons[row.sku] || ""}
                        onChange={(e) => setReasons({ ...reasons, [row.sku]: e.target.value })}
                        placeholder="Enter reason..."
                        className="w-full border border-amber-300 rounded px-2 py-1 text-xs bg-white"
                      />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="flex justify-end mt-3 gap-2">
            <button onClick={() => setOpnameMode(false)} className="text-sm px-4 py-2 rounded-lg bg-white border border-amber-300 text-amber-700 hover:bg-amber-50 transition-colors">
              Cancel
            </button>
            <button className="text-sm px-4 py-2 rounded-lg bg-amber-500 text-white hover:opacity-90 transition-opacity">
              Submit Opname Report
            </button>
          </div>
        </div>
      )}

      {/* Product Table */}
      <div className="bg-card rounded-xl border border-border shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-muted/40 border-b border-border">
                {["Product ID", "SKU", "Product Name", "Category", "Price (Rp)", "Stock Qty", "Reorder Point", "Status", "Actions"].map((h) => (
                  <th key={h} className="text-left py-3 px-4 text-xs text-muted-foreground" style={{ fontWeight: 600, whiteSpace: "nowrap" }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.map((p, i) => {
                const sc = statusConfig[p.status as keyof typeof statusConfig];
                return (
                  <tr key={p.id} className={`border-b border-border hover:bg-muted/20 transition-colors ${i % 2 === 0 ? "" : "bg-muted/5"}`}>
                    <td className="py-3 px-4 text-xs text-muted-foreground font-mono">{p.id}</td>
                    <td className="py-3 px-4 text-xs font-mono text-foreground">{p.sku}</td>
                    <td className="py-3 px-4 text-foreground" style={{ fontWeight: 500 }}>{p.name}</td>
                    <td className="py-3 px-4 text-muted-foreground">{p.category}</td>
                    <td className="py-3 px-4 text-foreground">{p.price.toLocaleString("id-ID")}</td>
                    <td className={`py-3 px-4 text-center ${p.stock === 0 ? "text-red-600 font-semibold" : p.stock < p.reorderPoint ? "text-amber-600 font-semibold" : "text-foreground"}`}>
                      {p.stock}
                    </td>
                    <td className="py-3 px-4 text-center text-muted-foreground">{p.reorderPoint}</td>
                    <td className="py-3 px-4">
                      <span className={`text-xs px-2 py-1 rounded-full border ${sc.className}`}>{sc.label}</span>
                    </td>
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-1">
                        <button className="text-xs px-2.5 py-1 rounded-md bg-blue-50 text-blue-700 hover:bg-blue-100 transition-colors">Edit</button>
                        <button className="text-xs px-2.5 py-1 rounded-md bg-muted text-muted-foreground hover:bg-secondary transition-colors">Adjust</button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
        <div className="px-5 py-3 border-t border-border flex items-center justify-between text-xs text-muted-foreground">
          <span>Showing {filtered.length} of {products.length} items</span>
          <div className="flex items-center gap-1">
            {[1, 2, 3].map((p) => (
              <button key={p} className={`w-7 h-7 rounded-md text-xs ${p === 1 ? "bg-primary text-white" : "bg-muted text-muted-foreground hover:bg-secondary"}`}>{p}</button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
