import { useState } from "react";
import { Search, RotateCcw, CheckCircle, Package } from "lucide-react";
import { toast } from "sonner";

const transactions = {
  "TXN-240601": {
    date: "2026-06-01",
    cashier: "Rina Wahyuni",
    items: [
      { sku: "BEV-MW-001", name: "Aqua Mineral Water 600ml", qty: 5, price: 4500 },
      { sku: "DRY-IND-007", name: "Indomie Goreng Original", qty: 10, price: 3500 },
      { sku: "SNK-CHI-003", name: "Chitato Potato Chips 68g", qty: 2, price: 12500 },
    ],
  },
  "TXN-240602": {
    date: "2026-06-02",
    cashier: "Ahmad Fauzi",
    items: [
      { sku: "TOIL-SOF-022", name: "Softex Body Wash 450ml", qty: 1, price: 28500 },
      { sku: "DRY-GUL-004", name: "Gulaku Gula Pasir 1kg", qty: 3, price: 16500 },
    ],
  },
};

const returnReasons = [
  "Product damaged / defective",
  "Wrong item received",
  "Customer changed mind",
  "Product expired",
  "Quantity mismatch",
  "Other",
];

const recentReturns = [
  { id: "RTN-2024-018", txn: "TXN-240588", product: "Oreo Double Stuff 132g", qty: 2, reason: "Product damaged", status: "quarantine", date: "2026-06-08" },
  { id: "RTN-2024-017", txn: "TXN-240571", product: "Aqua Mineral Water 600ml", qty: 5, reason: "Wrong item", status: "restocked", date: "2026-06-06" },
  { id: "RTN-2024-016", txn: "TXN-240545", product: "Softex Body Wash 450ml", qty: 1, reason: "Customer changed mind", status: "quarantine", date: "2026-06-04" },
];

export function SalesReturns() {
  const [txnId, setTxnId] = useState("");
  const [foundTxn, setFoundTxn] = useState<keyof typeof transactions | null>(null);
  const [selectedItems, setSelectedItems] = useState<Record<string, number>>({});
  const [reason, setReason] = useState("");
  const [customReason, setCustomReason] = useState("");

  const handleSearch = () => {
    const key = txnId.toUpperCase() as keyof typeof transactions;
    if (transactions[key]) {
      setFoundTxn(key);
      setSelectedItems({});
    } else {
      toast.error("Transaction Not Found", { description: `No transaction found for ID: ${txnId}` });
    }
  };

  const toggleItem = (sku: string, maxQty: number) => {
    setSelectedItems((prev) =>
      prev[sku] ? { ...prev, [sku]: undefined as unknown as number } : { ...prev, [sku]: 1 }
    );
  };

  const handleSubmit = () => {
    const itemCount = Object.values(selectedItems).filter(Boolean).length;
    if (!itemCount) { toast.error("Select at least one item to return."); return; }
    if (!reason) { toast.error("Please select a return reason."); return; }
    toast.success("Return Processed!", {
      description: `${itemCount} item(s) moved to Quarantine Stock — RTN-${Date.now().toString().slice(-6)}`,
    });
    setFoundTxn(null);
    setTxnId("");
    setSelectedItems({});
    setReason("");
  };

  const txn = foundTxn ? transactions[foundTxn] : null;

  return (
    <div className="p-6 space-y-5 min-h-screen">
      <div>
        <h1 className="text-xl text-foreground">Sales Returns</h1>
        <p className="text-sm text-muted-foreground mt-0.5">Process customer returns and move to quarantine stock</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {/* Return Form */}
        <div className="bg-card rounded-xl border border-border shadow-sm overflow-hidden">
          <div className="px-5 py-4 border-b border-border">
            <h2 className="text-foreground">New Return Request</h2>
          </div>
          <div className="p-5 space-y-4">
            <div>
              <label className="text-xs text-muted-foreground block mb-1.5">Transaction ID</label>
              <div className="flex gap-2">
                <input
                  value={txnId}
                  onChange={(e) => setTxnId(e.target.value)}
                  placeholder="e.g. TXN-240601"
                  className="flex-1 px-3 py-2 text-sm rounded-lg border border-border bg-input-background focus:outline-none focus:ring-2 focus:ring-ring"
                  onKeyDown={(e) => e.key === "Enter" && handleSearch()}
                />
                <button
                  onClick={handleSearch}
                  className="flex items-center gap-2 px-4 py-2 text-sm bg-primary text-white rounded-lg hover:opacity-90 transition-opacity"
                >
                  <Search className="w-3.5 h-3.5" /> Lookup
                </button>
              </div>
            </div>

            {txn && (
              <>
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
                  <p className="text-xs text-blue-700" style={{ fontWeight: 600 }}>Transaction Found: {foundTxn}</p>
                  <p className="text-xs text-blue-600 mt-0.5">{txn.date} — Cashier: {txn.cashier}</p>
                </div>

                <div>
                  <label className="text-xs text-muted-foreground block mb-2">Select Items to Return</label>
                  <div className="space-y-2 border border-border rounded-lg overflow-hidden">
                    {txn.items.map((item) => (
                      <label key={item.sku} className={`flex items-center gap-3 px-3 py-3 cursor-pointer transition-colors border-b border-border/50 last:border-0 ${selectedItems[item.sku] ? "bg-blue-50/50" : "hover:bg-muted/20"}`}>
                        <input
                          type="checkbox"
                          checked={!!selectedItems[item.sku]}
                          onChange={() => toggleItem(item.sku, item.qty)}
                          className="rounded border-border accent-primary"
                        />
                        <div className="flex-1">
                          <p className="text-sm text-foreground" style={{ fontWeight: 500 }}>{item.name}</p>
                          <p className="text-xs text-muted-foreground">Qty purchased: {item.qty} — Rp {item.price.toLocaleString("id-ID")}/unit</p>
                        </div>
                        {selectedItems[item.sku] !== undefined && (
                          <input
                            type="number"
                            value={selectedItems[item.sku] || 1}
                            onChange={(e) => setSelectedItems({ ...selectedItems, [item.sku]: parseInt(e.target.value) || 1 })}
                            min={1}
                            max={item.qty}
                            className="w-16 text-center text-sm border border-border rounded-md px-1 py-1"
                          />
                        )}
                      </label>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="text-xs text-muted-foreground block mb-1.5">Return Reason</label>
                  <select
                    value={reason}
                    onChange={(e) => setReason(e.target.value)}
                    className="w-full px-3 py-2 text-sm rounded-lg border border-border bg-input-background focus:outline-none focus:ring-2 focus:ring-ring"
                  >
                    <option value="">Select reason...</option>
                    {returnReasons.map((r) => <option key={r} value={r}>{r}</option>)}
                  </select>
                  {reason === "Other" && (
                    <input
                      value={customReason}
                      onChange={(e) => setCustomReason(e.target.value)}
                      placeholder="Describe the reason..."
                      className="mt-2 w-full px-3 py-2 text-sm rounded-lg border border-border bg-input-background focus:outline-none focus:ring-2 focus:ring-ring"
                    />
                  )}
                </div>

                <div className="bg-amber-50 border border-amber-200 rounded-lg p-3 flex items-start gap-2">
                  <Package className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                  <p className="text-xs text-amber-700">Returned items will be automatically moved to <strong>Quarantine Stock</strong> for quality inspection before restocking.</p>
                </div>

                <button onClick={handleSubmit} className="w-full flex items-center justify-center gap-2 py-2.5 text-sm bg-primary text-white rounded-lg hover:opacity-90 transition-opacity">
                  <RotateCcw className="w-4 h-4" /> Process Return
                </button>
              </>
            )}

            {!txn && (
              <div className="flex flex-col items-center justify-center py-12 text-center">
                <RotateCcw className="w-10 h-10 text-muted-foreground/30 mb-3" />
                <p className="text-sm text-muted-foreground">Enter a Transaction ID to begin</p>
                <p className="text-xs text-muted-foreground/60 mt-1">Try: TXN-240601 or TXN-240602</p>
              </div>
            )}
          </div>
        </div>

        {/* Recent Returns */}
        <div className="bg-card rounded-xl border border-border shadow-sm overflow-hidden">
          <div className="px-5 py-4 border-b border-border flex items-center justify-between">
            <h2 className="text-foreground">Recent Returns</h2>
            <span className="text-xs text-muted-foreground bg-muted px-2 py-1 rounded-md">Last 7 days</span>
          </div>
          <div className="divide-y divide-border">
            {recentReturns.map((r) => (
              <div key={r.id} className="px-5 py-4 hover:bg-muted/20 transition-colors">
                <div className="flex items-start justify-between gap-3">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <p className="text-sm text-foreground" style={{ fontWeight: 600 }}>{r.id}</p>
                      <span className="text-xs text-muted-foreground">← {r.txn}</span>
                      <span className={`text-[10px] px-2 py-0.5 rounded-full border ${
                        r.status === "quarantine"
                          ? "bg-amber-50 text-amber-700 border-amber-200"
                          : "bg-emerald-50 text-emerald-700 border-emerald-200"
                      }`}>
                        {r.status === "quarantine" ? "Quarantine" : "Restocked"}
                      </span>
                    </div>
                    <p className="text-sm text-foreground mt-1">{r.product}</p>
                    <p className="text-xs text-muted-foreground mt-0.5">Qty: {r.qty} — {r.reason}</p>
                  </div>
                  <div className="text-right shrink-0">
                    <p className="text-xs text-muted-foreground">{r.date}</p>
                    {r.status === "quarantine" && (
                      <button className="mt-2 flex items-center gap-1 text-xs px-2.5 py-1 rounded-md bg-emerald-50 text-emerald-700 border border-emerald-200 hover:bg-emerald-100 transition-colors">
                        <CheckCircle className="w-3 h-3" /> Restock
                      </button>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
          <div className="px-5 py-4 bg-muted/20 border-t border-border">
            <div className="grid grid-cols-3 gap-3 text-center">
              <div>
                <p className="text-xs text-muted-foreground">Total Returns</p>
                <p className="text-foreground" style={{ fontWeight: 700 }}>18</p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground">In Quarantine</p>
                <p className="text-amber-700" style={{ fontWeight: 700 }}>11</p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Restocked</p>
                <p className="text-emerald-700" style={{ fontWeight: 700 }}>7</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
