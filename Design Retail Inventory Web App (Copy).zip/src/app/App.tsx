import { useState } from "react";
import { Toaster } from "sonner";
import { Sidebar } from "./components/Sidebar";
import { Dashboard } from "./components/Dashboard";
import { Inventory } from "./components/Inventory";
import { Procurement } from "./components/Procurement";
import { POS } from "./components/POS";
import { SalesReturns } from "./components/SalesReturns";
import { AuditLogs } from "./components/AuditLogs";

const pages: Record<string, React.ComponentType> = {
  dashboard: Dashboard,
  inventory: Inventory,
  procurement: Procurement,
  pos: POS,
  returns: SalesReturns,
  audit: AuditLogs,
};

export default function App() {
  const [activePage, setActivePage] = useState("dashboard");

  const PageComponent = pages[activePage] || Dashboard;

  const isPOS = activePage === "pos";

  return (
    <div className="flex h-screen w-full overflow-hidden bg-background">
      <Toaster position="top-right" richColors />
      <Sidebar activePage={activePage} onNavigate={setActivePage} />
      <main className={`flex-1 overflow-auto ${isPOS ? "" : ""}`}>
        <PageComponent />
      </main>
    </div>
  );
}
